<?php

header('Content-Type: text/html; charset=utf-8');

// @error_reporting(E_ALL);
// @ini_set('display_errors', 'On');
@error_reporting(0);
@ini_set('display_errors', 'Off');
@ini_set('error_log', 'data/error_log.txt');

include_once 'data/conf.php';
require_once 'inc/func.php';
require_once 'inc/FkApi.php';

file_put_contents('logs/cron.txt', date('Y-m-d H:i:s', time()) . '||start' . PHP_EOL, FILE_APPEND | LOCK_EX);

$fkapi = new FkApi($conf['fk_mid'], $conf['fk_secret'], $conf['fk_secret2'], $conf['fk_apikey']);


// Проверка баланса
if (!$fkapi->balance()) {
    file_put_contents('logs/balance_error1.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
}
if ($fkapi->getType() != 'success') {
    file_put_contents('logs/balance_error2.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
}


// file_put_contents('logs/balance.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);


// Проверяем наличие средств(RUB)
if (!empty($fkapi->getResponse('balance')) && is_array($fkapi->getResponse('balance'))) {
    $items = $fkapi->getResponse('balance');
    // Ищем RUB
    foreach ($items as $item) {
        if ($item['currency'] == 'RUB') {
            $amount = $item['value']; // средства RUB
            break;
        }
    }
}

// $amount = 0;

// Если средства есть и их больше 10...
if (!empty($amount) && $amount >= 10) {
    file_put_contents('logs/payment.txt', date('Y-m-d H:i:s', time()) . '||' . $amount . PHP_EOL, FILE_APPEND | LOCK_EX);

    // Формируем запрос, на выплату
    $fkapi->setI(1) // FK WALLET RUB
        ->setAccount($conf['fk_wallet'])
        ->setAmount($amount)
        ->setCurrency('RUB');

    // отправляем запрос на выплату
    if (!$fkapi->withdrawals_create()) {
        file_put_contents('logs/withdrawals_error1.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    // Проверка успешности
    if ((string) $fkapi->getType() != 'success') {
        file_put_contents('logs/withdrawals_error2.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
    } else {
        file_put_contents('logs/payment_success.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}


file_put_contents('logs/cron.txt', date('Y-m-d H:i:s', time()) . '||end' . PHP_EOL, FILE_APPEND | LOCK_EX);