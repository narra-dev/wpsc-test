<?php

header('Content-Type: text/html; charset=utf-8');

// @error_reporting(E_ALL);
// @ini_set('display_errors', 'On');
@error_reporting(0);
@ini_set('display_errors', 'Off');
@ini_set('error_log', 'data/error_log.txt');

include_once 'data/conf.php';
require_once 'inc/func.php';
require_once 'inc/FkApi.php';


// Проверяем наличие и берем данные, из json файла
if (!file_exists('orders/order.json')) die('not found order.json');
$data = @json_decode(trim(file_get_contents('orders/order.json')), true);

// Проверяем наличие данных, в самом файле
if (empty($data[0]['dealNumber'])) die('not found dealNumber');
$dealNumber = $data[0]['dealNumber'];
if (empty($data[0]['dealTotal'])) die('not found dealTotal');
$dealTotal = $data[0]['dealTotal'];

// FK
$fkapi = new FkApi($conf['fk_mid'], $conf['fk_secret'], $conf['fk_secret2'], $conf['fk_apikey']);


// Формируем запрос
$fkapi->setI(36) // ID платежной системы(integer)
    ->setEmail('test@mail.com') // Email покупателя(string)
    ->setIp(getIP()) // IP покупателя(string)    
    ->setCurrency('RUB') // Валюта оплаты(string)
    ->setAmount($dealTotal) // Сумма оплаты(numeric)
    ->setPaymentId($dealNumber); // Номер заказа в Вашем магазине(string)



// Отправляем запрос, на создание заказа
if (!$fkapi->orders_create()) {
    file_put_contents('logs/error1.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
    die('Error(1)');
}

// Проверяем наличие метки об успешности
if ($fkapi->getType() != 'success') {
    file_put_contents('logs/error2.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
    die('Error(2)');
}

// Проверяем наличие урла заказа
if (empty($fkapi->getResponse('location'))) {
    file_put_contents('logs/error3.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
    die('Error(3)');
}

file_put_contents('logs/index.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Site</title>
    <!-- <link rel="stylesheet" href="./style.css">
    <link rel="icon" href="./favicon.ico" type="image/x-icon"> -->
</head>

<body>
    <main>
        <div style="text-align: center;">
            <h1><a href="<?= $fkapi->getResponse('location'); ?>" target="_blank">Click Me</a></h1>
        </div>
    </main>
</body>

</html>