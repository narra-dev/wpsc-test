<?php


// http://wspc13.beget.tech/
// http://wspc13.beget.tech/fkapi.php
// http://wspc13.beget.tech/order?act=run
// http://wspc13.beget.tech/order?act=error

// fkwallet F112408007

$conf['fk_mid'] = '34419';
$conf['fk_secret'] = 'xN$YJt0+QYS=&a]shS*hc9sha2@';
$conf['fk_secret2'] = '_ww]?eHi/37sBe[ch8ah@gda83d';
$conf['fk_apikey'] = '61445a127d357e7babc9b62209896f1d';

$conf['fk_ip'] = ['168.119.157.136', '168.119.60.227', '138.201.88.124', '178.154.197.79'];

$conf['fk_wallet'] = 'F112408007';

// api
// 61445a127d357e7babc9b62209896f1d