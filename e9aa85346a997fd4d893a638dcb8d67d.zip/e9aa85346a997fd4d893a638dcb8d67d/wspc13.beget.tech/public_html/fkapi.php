<?php

header('Content-Type: text/html; charset=utf-8');

// @error_reporting(E_ALL);
// @ini_set('display_errors', 'On');
@error_reporting(0);
@ini_set('display_errors', 'Off');
@ini_set('error_log', 'data/error_log.txt');

include_once 'data/conf.php';
require_once 'inc/func.php';
require_once 'inc/FkApi.php';

$save_path = dirname(__DIR__) . '/app/successfulPayments';

// Проверка по IP, расскоментировать при необходимости
// if (!in_array(getIP(), (array) $conf['fk_ip'])) {
//    file_put_contents('logs/hacking.txt', getIP() . PHP_EOL, FILE_APPEND | LOCK_EX);
//    die("hacking attempt!");
// }

$fkapi = new FkApi($conf['fk_mid'], $conf['fk_secret'], $conf['fk_secret2'], $conf['fk_apikey']);

$fkapi->load();

file_put_contents('logs/paydata.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($_POST) . PHP_EOL, FILE_APPEND | LOCK_EX);

// check data
if (!$fkapi->validate()) {
	file_put_contents('logs/wrong.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($_POST) . PHP_EOL, FILE_APPEND | LOCK_EX);
	file_put_contents('logs/wrong2.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getErrors()) . PHP_EOL, FILE_APPEND | LOCK_EX);
	die('wrong');
}

// Так же, рекомендуется добавить проверку на сумму платежа и не была ли эта заявка уже оплачена или отменена
// ...



// Проверка баланса
if ($fkapi->balance()) {
	if (!empty($fkapi->getType()) && $fkapi->getType() == 'success') {

		// file_put_contents('logs/balance.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);

		// Проверяем наличие средств(RUB)
		if (!empty($fkapi->getResponse('balance')) && is_array($fkapi->getResponse('balance'))) {
			$items = $fkapi->getResponse('balance');
			// Ищем RUB
			foreach ($items as $item) {
				if ($item['currency'] == 'RUB') {
					$amount = $item['value']; // средства RUB
					break;
				}
			}
		}

		// $amount = 0;

		// Если средства есть и их больше 10...
		if (!empty($amount) && $amount >= 10) {
			file_put_contents('logs/payment.txt', date('Y-m-d H:i:s', time()) . '||' . $amount . PHP_EOL, FILE_APPEND | LOCK_EX);

			// Формируем запрос, на выплату
			$fkapi->setI(1) // FK WALLET RUB
				->setAccount($conf['fk_wallet'])
				->setAmount($amount)
				->setCurrency('RUB');

			// отправляем запрос на выплату
			if (!$fkapi->withdrawals_create()) {
				file_put_contents('logs/withdrawals_error1.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
			}

			// Проверка успешности
			if ((string) $fkapi->getType() != 'success') {
				file_put_contents('logs/withdrawals_error2.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
			} else {
				file_put_contents('logs/payment_success.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
			}
		}
	}
}


// Фиксация успешности оплаты
file_put_contents($save_path . '/order' . $fkapi->getDataMerchantOrderId() . '.json', 'true', LOCK_EX);

// success
file_put_contents('logs/success.txt', date('Y-m-d H:i:s', time()) . '||' . serialize($fkapi->getResponse()) . PHP_EOL, FILE_APPEND | LOCK_EX);
die('YES');