<?php

function getIP()
{
    if (isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
    return $_SERVER['REMOTE_ADDR'];
}

function print_arr($arr)
{
    echo '<pre>';
    print_r($arr);
    echo '</pre>';
}