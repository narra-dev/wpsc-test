<?php

class FkApi
{
    private $_mid; // shopId
    private $_secret;
    private $_secret2;
    private $_api_key;

    private $_url = "https://api.freekassa.ru/v1/";

    private $data = [];

    // API
    private $account;

    private $order_id;
    private $payment_id;
    private $i;
    private $email;
    private $ip;
    private $amount;
    private $currency = 'RUB';
    private $tel;
    private $order_status;
    private $date_from;
    private $date_to;
    private $page;

    // REQUEST
    private $type;
    private $result;
    private $response;

    // ERRORS
    private $errors = [];

    public function __construct($mid, $secret, $secret2, $api_key)
    {
        $this->_mid = trim($mid);
        $this->_secret = $secret;
        $this->_secret2 = $secret2;
        $this->_api_key = $api_key;
    }

    public function balance()
    {
        $url = $this->_url . 'balance';

        $data = [
            'shopId' => $this->_mid,
            'nonce' => time(),
        ];
        ksort($data);
        $sign = hash_hmac('sha256', implode('|', $data), $this->_api_key);
        $data['signature'] = $sign;

        return $this->request($url, $data);
    }

    public function orders()
    {
        $url = $this->_url . 'orders';

        $data = [
            'shopId' => $this->_mid,
            'nonce' => time(),
        ];
        ksort($data);
        $sign = hash_hmac('sha256', implode('|', $data), $this->_api_key);
        $data['signature'] = $sign;

        return $this->request($url, $data);
    }

    /**
     * Создать заказ и получить ссылку на оплату
     */
    public function orders_create()
    {
        $url = $this->_url . 'orders/create';

        $data = [
            'shopId' => $this->_mid,
            'nonce' => time(),
            'paymentId' => $this->payment_id,
            'i' => $this->i,
            'email' => $this->email,
            'ip' => $this->ip,
            'amount' => $this->amount,
            'currency' => $this->currency,            
        ];

        ksort($data);
        $sign = hash_hmac('sha256', implode('|', $data), $this->_api_key);
        $data['signature'] = $sign;

        return $this->request($url, $data);
    }

    /**
     * Создать выплату
     */
    public function withdrawals_create()
    {
        $url = $this->_url . 'withdrawals/create';

        $data = [
            'shopId' => $this->_mid,
            'nonce' => time(),
            'paymentId' => $this->payment_id,
            'i' => $this->i,
            'account' => $this->account,
            'amount' => $this->amount,
            'currency' => $this->currency
        ];

        ksort($data);
        $sign = hash_hmac('sha256', implode('|', $data), $this->_api_key);
        $data['signature'] = $sign;

        return $this->request($url, $data);
    }

    /**
     * Список выплат
     */
    public function withdrawals()
    {
        $url = $this->_url . 'withdrawals';

        $data = [
            'shopId' => $this->_mid,
            'nonce' => time(),
            'orderId' => $this->order_id,
            'paymentId' => $this->payment_id,
            'orderStatus' => $this->order_status,
            'dateFrom' => $this->date_from,
            'dateTo' => $this->date_to,
            'page' => $this->page
        ];

        ksort($data);
        $sign = hash_hmac('sha256', implode('|', $data), $this->_api_key);
        $data['signature'] = $sign;

        return $this->request($url, $data);
    }

    public function validate()
    {
        if (empty($this->data['SIGN'])) {
            $this->errors[] = 'Не передана подпись';
            return false;
        }

        if (empty($this->data['AMOUNT'])) {
            $this->errors[] = 'Не передана сумма платежа';
            return false;
        }

        if (!isset($this->data['MERCHANT_ORDER_ID'])) {
            $this->errors[] = 'Не передан номер заказа';
            return false;
        }
        if (empty($this->data['MERCHANT_ID'])) {
            $this->errors[] = 'Не передан ID мерчанта';
            return false;
        }

        $sign = md5($this->data['MERCHANT_ID'] . ':' . $this->data['AMOUNT'] . ':' . $this->_secret2 . ':' . $this->data['MERCHANT_ORDER_ID']);

        if ($sign != $this->data['SIGN']) {
            $this->errors[] = 'Подписи не совпадают';
            return false;
        }

        return true;
    }

    /**
     * Номер заказа в Вашем магазине(string)
     */
    public function setPaymentId($payment_id)
    {
        $this->payment_id = $payment_id;
        return $this;
    }

    /**
     * ID платежной системы
     */
    public function setI($i)
    {
        $this->i = $i;
        return $this;
    }


    /**
     * Email покупателя(string)
     */
    public function setEmail($email)
    {
        $this->email = $email;
        return $this;
    }

    /**
     * IP покупателя(string)
     */
    public function setIp($ip)
    {
        $this->ip = $ip;
        return $this;
    }

    /**
     * Сумма оплаты(numeric)
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;
        return $this;
    }

    /**
     * Валюта оплаты(string)
     */
    public function setCurrency($currency)
    {
        $this->currency = $currency;
        return $this;
    }

    /**
     * Кошелек для зачисления средств (при выплате на FKWallet вывод осуществляется только на свой аккаунт)
     */
    public function setAccount($account)
    {
        $this->account = $account;
        return $this;
    }


    private function request($url, $data = [])
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_FAILONERROR, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        $this->result = trim(curl_exec($ch));
        curl_close($ch);

        $this->response = @json_decode($this->result, true);

        if (empty($this->response)) return false;

        if (!empty($this->response['type'])) $this->type = trim($this->response['type']);

        return true;
    }

    /**
     * Тип ответа Api(success, error)
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Ответ Api
     */
    public function getResult()
    {
        return $this->result;
    }

    /**
     * Ответ Api(массив)
     */
    public function getResponse($key = null, $defaut = null)
    {
        if (empty($key)) return $this->response;
        if (!empty($key) && isset($this->response[$key])) return $this->response[$key];
        return $defaut;
    }

    public function getErrors()
    {
        return $this->errors;
    }

    public function getData()
    {
        return $this->data;
    }

    public function getDataMerchantOrderId($default = '')
    {
        if (isset($this->data['MERCHANT_ORDER_ID'])) return $this->data['MERCHANT_ORDER_ID'];
        return $default;
    }

    /**
     * Загрузка данных
     */
    public function load($data = [])
    {
        if (!empty($data)) {
            $this->data = $data;
            return true;
        }
        if (!empty($_POST)) {
            $this->data = $_POST;
            return true;
        }

        return false;
    }
}
